
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
# En este init py se importan los nombres de los archivos que se encuentren dentro de models a medida que se vayan creando

from . import instituto_alumno
from . import instituto_valoracion
from . import instituto_practicas
from . import instituto_empresa
from . import instituto_profesor
from . import instituto_asignatura
